function removeValueFromArray(array, value) {
    return array.filter(item => item !== value);
}

module.exports = removeValueFromArray;
